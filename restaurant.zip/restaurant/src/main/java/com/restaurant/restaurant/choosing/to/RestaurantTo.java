package com.restaurant.restaurant.choosing.to;


import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

import com.restaurant.restaurant.model.Restaurant;



@NoArgsConstructor
@Data
public class RestaurantTo {
    private List<LunchTo> lunches;
    private String name;

    public RestaurantTo(Restaurant restaurant, List<LunchTo> lunches) {
        this.name = restaurant.getName();
        this.lunches = lunches;
    }
}
