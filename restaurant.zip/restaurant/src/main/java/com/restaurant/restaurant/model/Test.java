package com.restaurant.restaurant.model;

public class Test {

}
